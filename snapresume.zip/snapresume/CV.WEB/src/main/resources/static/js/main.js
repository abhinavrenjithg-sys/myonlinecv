/**
 * main.js – Abhinav R Portfolio
 * Handles: particle canvas, typewriter, scroll reveal,
 * skill bar animation, navbar scroll, hamburger menu,
 * contact form API submission, toast notifications.
 */

/* =====================================================
   1. PARTICLE CANVAS
===================================================== */
(function initParticles() {
    const canvas = document.getElementById('particleCanvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let particles = [];
    let W, H;

    function resize() {
        W = canvas.width = window.innerWidth;
        H = canvas.height = window.innerHeight;
    }

    function createParticle() {
        return {
            x: Math.random() * W,
            y: Math.random() * H,
            r: Math.random() * 1.5 + 0.3,
            vx: (Math.random() - 0.5) * 0.4,
            vy: -(Math.random() * 0.5 + 0.1),
            alpha: Math.random() * 0.5 + 0.1,
            color: Math.random() > 0.5 ? '#6366f1' : '#8b5cf6'
        };
    }

    function init() {
        resize();
        particles = Array.from({ length: 90 }, createParticle);
    }

    function draw() {
        ctx.clearRect(0, 0, W, H);
        particles.forEach(p => {
            ctx.save();
            ctx.globalAlpha = p.alpha;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
            ctx.fillStyle = p.color;
            ctx.fill();
            ctx.restore();
            p.x += p.vx;
            p.y += p.vy;
            if (p.y < -10) { Object.assign(p, createParticle(), { y: H + 5 }); }
        });

        // Draw connecting lines
        for (let i = 0; i < particles.length; i++) {
            for (let j = i + 1; j < particles.length; j++) {
                const dx = particles[i].x - particles[j].x;
                const dy = particles[i].y - particles[j].y;
                const dist = Math.sqrt(dx * dx + dy * dy);
                if (dist < 100) {
                    ctx.save();
                    ctx.globalAlpha = (1 - dist / 100) * 0.12;
                    ctx.strokeStyle = '#6366f1';
                    ctx.lineWidth = 0.5;
                    ctx.beginPath();
                    ctx.moveTo(particles[i].x, particles[i].y);
                    ctx.lineTo(particles[j].x, particles[j].y);
                    ctx.stroke();
                    ctx.restore();
                }
            }
        }
        requestAnimationFrame(draw);
    }

    window.addEventListener('resize', resize);
    init();
    draw();
})();


/* =====================================================
   2. TYPEWRITER EFFECT
===================================================== */
(function initTypewriter() {
    const el = document.getElementById('typewriter');
    if (!el) return;

    const phrases = [
        'AI & ML Developer',
        'Data Scientist',
        'Neural Network Engineer',
        'Python Developer',
        'Machine Learning Enthusiast',
    ];

    let phraseIdx = 0, charIdx = 0, deleting = false;

    function tick() {
        const current = phrases[phraseIdx];
        el.textContent = deleting
            ? current.slice(0, charIdx--)
            : current.slice(0, charIdx++);

        let delay = deleting ? 50 : 80;

        if (!deleting && charIdx > current.length) {
            delay = 2000;  // pause before deleting
            deleting = true;
        } else if (deleting && charIdx < 0) {
            deleting = false;
            charIdx = 0;
            phraseIdx = (phraseIdx + 1) % phrases.length;
            delay = 400;
        }
        setTimeout(tick, delay);
    }
    tick();
})();


/* =====================================================
   3. NAVBAR SCROLL EFFECT + ACTIVE LINKS
===================================================== */
(function initNavbar() {
    const nav = document.getElementById('navbar');
    const links = document.querySelectorAll('.nav-link');
    const sections = document.querySelectorAll('section[id]');

    window.addEventListener('scroll', () => {
        // Glassmorphism on scroll
        if (window.scrollY > 60) {
            nav.classList.add('scrolled');
        } else {
            nav.classList.remove('scrolled');
        }

        // Active link highlight
        let current = '';
        sections.forEach(sec => {
            if (window.scrollY >= sec.offsetTop - 120) {
                current = sec.getAttribute('id');
            }
        });
        links.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === '#' + current) {
                link.classList.add('active');
            }
        });
    });
})();


/* =====================================================
   4. HAMBURGER MOBILE MENU
===================================================== */
(function initHamburger() {
    const btn = document.getElementById('hamburger');
    const menu = document.getElementById('mobileMenu');
    if (!btn || !menu) return;

    btn.addEventListener('click', () => {
        const open = menu.classList.toggle('mobile-menu-open');
        menu.classList.toggle('mobile-menu-hidden', !open);
        btn.classList.toggle('hamburger-open', open);
    });

    // Close on link click
    menu.querySelectorAll('a').forEach(a => {
        a.addEventListener('click', () => {
            menu.classList.remove('mobile-menu-open');
            menu.classList.add('mobile-menu-hidden');
            btn.classList.remove('hamburger-open');
        });
    });
})();


/* =====================================================
   5. SCROLL REVEAL + SKILL BARS (Intersection Observer)
===================================================== */
(function initReveal() {
    const revealEls = document.querySelectorAll('.reveal');
    const barFills = document.querySelectorAll('.bar-fill');
    let barsAnimated = false;

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.12 });

    revealEls.forEach(el => observer.observe(el));

    // Skill bar observer (trigger once when section scrolls in)
    const barObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting && !barsAnimated) {
                barsAnimated = true;
                barFills.forEach(fill => {
                    const target = fill.getAttribute('data-width');
                    fill.style.width = target + '%';
                });
            }
        });
    }, { threshold: 0.2 });

    const skillsSection = document.getElementById('skills');
    if (skillsSection) barObserver.observe(skillsSection);
})();


/* =====================================================
   6. CONTACT FORM (REST API call to /api/contact)
===================================================== */
(function initContactForm() {
    const form = document.getElementById('contactForm');
    const btnText = document.getElementById('btnText');
    const spinner = document.getElementById('btnSpinner');
    const submitBtn = document.getElementById('submitBtn');
    const statusEl = document.getElementById('formStatus');
    if (!form) return;

    function showStatus(msg, success) {
        statusEl.textContent = msg;
        statusEl.className = success
            ? 'text-center text-sm py-2 px-4 rounded-lg font-medium bg-green-500/10 border border-green-500/20 text-green-400'
            : 'text-center text-sm py-2 px-4 rounded-lg font-medium bg-red-500/10 border border-red-500/20 text-red-400';
        statusEl.classList.remove('hidden');
        setTimeout(() => statusEl.classList.add('hidden'), 5000);
    }

    function showToast(msg, success) {
        const toast = document.getElementById('toast');
        if (!toast) return;
        toast.textContent = msg;
        toast.className = success
            ? 'toast-show fixed bottom-6 right-6 z-[100] px-5 py-3 rounded-xl text-sm font-medium shadow-xl transition-all duration-300 toast-success'
            : 'toast-show fixed bottom-6 right-6 z-[100] px-5 py-3 rounded-xl text-sm font-medium shadow-xl transition-all duration-300 toast-error';
        setTimeout(() => {
            toast.className = 'toast-hidden fixed bottom-6 right-6 z-[100] px-5 py-3 rounded-xl text-sm font-medium shadow-xl transition-all duration-300';
        }, 4500);
    }

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        // Basic validation
        const name = form.name.value.trim();
        const email = form.email.value.trim();
        const subject = form.subject.value.trim();
        const message = form.message.value.trim();

        if (!name || !email || !subject || !message) {
            showStatus('Please fill in all fields.', false);
            return;
        }

        // Loading state
        btnText.textContent = 'Sending…';
        spinner.classList.remove('hidden');
        submitBtn.disabled = true;

        try {
            const response = await fetch('/api/contact', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, email, subject, message }),
            });

            const data = await response.json();

            if (response.ok) {
                form.reset();
                showStatus('✅ Message sent successfully! I\'ll get back to you shortly.', true);
                showToast('Message sent! 🎉', true);
            } else {
                throw new Error(data.message || 'Something went wrong.');
            }
        } catch (err) {
            // Fallback: If backend isn't running (static file mode), open mailto
            const mailtoUrl = `mailto:abhinavrenjithg@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(`Name: ${name}\nEmail: ${email}\n\n${message}`)}`;
            showStatus('Backend not running – opening email client instead.', false);
            showToast('Opening email client…', false);
            setTimeout(() => window.location.href = mailtoUrl, 800);
        } finally {
            btnText.textContent = 'Send Message ✈️';
            spinner.classList.add('hidden');
            submitBtn.disabled = false;
        }
    });
})();


/* =====================================================
   7. SMOOTH SCROLL for anchor links (fallback)
===================================================== */
document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
        const target = document.querySelector(a.getAttribute('href'));
        if (target) {
            e.preventDefault();
            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    });
});
