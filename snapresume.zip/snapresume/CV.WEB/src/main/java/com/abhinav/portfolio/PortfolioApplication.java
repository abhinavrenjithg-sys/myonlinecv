package com.abhinav.portfolio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main entry point for Abhinav R's Portfolio Spring Boot application.
 * Serves the frontend from src/main/resources/static/ and exposes
 * REST endpoints (e.g. POST /api/contact) for dynamic features.
 */
@SpringBootApplication
public class PortfolioApplication {

    public static void main(String[] args) {
        SpringApplication.run(PortfolioApplication.class, args);
    }
}
