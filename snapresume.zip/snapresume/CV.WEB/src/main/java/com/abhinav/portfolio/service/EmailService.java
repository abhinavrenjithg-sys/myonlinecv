package com.abhinav.portfolio.service;

import com.abhinav.portfolio.model.ContactMessage;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

/**
 * Service responsible for sending contact form emails via SMTP.
 * SMTP credentials are configured in application.properties.
 *
 * To enable email: fill in spring.mail.* properties with your
 * Gmail / SMTP provider credentials.
 */
@Service
public class EmailService {

    private final JavaMailSender mailSender;

    /** The address that will receive contact form messages. */
    @Value("${portfolio.contact.recipient:abhinavrenjithg@gmail.com}")
    private String recipientEmail;

    public EmailService(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    /**
     * Sends a plain-text notification email when a visitor submits the contact form.
     *
     * @param msg the validated ContactMessage from the frontend
     */
    public void sendContactEmail(ContactMessage msg) {
        SimpleMailMessage email = new SimpleMailMessage();
        email.setTo(recipientEmail);
        email.setSubject("[Portfolio Contact] " + msg.getSubject());
        email.setText(
            "New message from your portfolio contact form:\n\n" +
            "Name:    " + msg.getName()    + "\n" +
            "Email:   " + msg.getEmail()   + "\n" +
            "Subject: " + msg.getSubject() + "\n\n" +
            "Message:\n" + msg.getMessage()
        );
        email.setReplyTo(msg.getEmail());
        mailSender.send(email);
    }
}
