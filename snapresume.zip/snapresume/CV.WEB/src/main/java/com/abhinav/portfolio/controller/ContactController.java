package com.abhinav.portfolio.controller;

import com.abhinav.portfolio.model.ContactMessage;
import com.abhinav.portfolio.service.EmailService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * REST controller for the portfolio contact form.
 *
 * Endpoint: POST /api/contact
 * Accepts a JSON body of ContactMessage, validates it, and dispatches
 * an email notification via EmailService.
 */
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")  // Allow requests from the static frontend
public class ContactController {

    private final EmailService emailService;

    public ContactController(EmailService emailService) {
        this.emailService = emailService;
    }

    /**
     * Handles contact form submissions.
     *
     * @param msg validated contact form payload from frontend
     * @return 200 OK on success, 500 on email dispatch error
     */
    @PostMapping("/contact")
    public ResponseEntity<Map<String, String>> handleContact(
            @Valid @RequestBody ContactMessage msg) {
        try {
            emailService.sendContactEmail(msg);
            return ResponseEntity.ok(Map.of(
                "status", "success",
                "message", "Thank you! Your message has been sent."
            ));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(Map.of(
                "status", "error",
                "message", "Failed to send message. Please try again or email directly."
            ));
        }
    }

    /**
     * Health check endpoint — GET /api/health
     * Useful for verifying the backend is running.
     */
    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        return ResponseEntity.ok(Map.of("status", "UP", "service", "portfolio-api"));
    }
}
