/* ─── SnapResume app.js ─── */

// ── Nav scroll effect ──
window.addEventListener('scroll', () => {
  const nav = document.getElementById('navbar');
  nav.classList.toggle('scrolled', window.scrollY > 20);
});

// ── Hero ring animation ──
function animateHeroRing() {
  const ring = document.getElementById('hero-ring');
  const numEl = document.getElementById('hero-ring-num');
  if (!ring || !numEl) return;
  const target = 87;
  const circumference = 2 * Math.PI * 40; // 251.2
  setTimeout(() => {
    ring.style.strokeDashoffset = circumference - (target / 100) * circumference;
    let curr = 0;
    const interval = setInterval(() => {
      curr += 2;
      numEl.textContent = curr + '%';
      if (curr >= target) { numEl.textContent = target + '%'; clearInterval(interval); }
    }, 20);
  }, 600);
}
animateHeroRing();

// ── Add SVG gradient defs ──
function injectSvgDefs() {
  const svgNS = 'http://www.w3.org/2000/svg';
  const defs = document.createElementNS(svgNS, 'defs');
  const grad = document.createElementNS(svgNS, 'linearGradient');
  grad.setAttribute('id', 'ringGrad');
  grad.setAttribute('x1', '0%'); grad.setAttribute('y1', '0%');
  grad.setAttribute('x2', '100%'); grad.setAttribute('y2', '100%');
  const stop1 = document.createElementNS(svgNS, 'stop');
  stop1.setAttribute('offset', '0%'); stop1.setAttribute('stop-color', '#6C63FF');
  const stop2 = document.createElementNS(svgNS, 'stop');
  stop2.setAttribute('offset', '100%'); stop2.setAttribute('stop-color', '#38BDF8');
  grad.appendChild(stop1); grad.appendChild(stop2);
  defs.appendChild(grad);

  // Append to first SVG that has a ring-fill
  const svg = document.querySelector('.ring-svg');
  if (svg) svg.prepend(defs);

  const svg2 = document.querySelector('.score-ring-svg');
  if (svg2) {
    const defs2 = defs.cloneNode(true);
    svg2.prepend(defs2);
  }
}
injectSvgDefs();

// ── Tab switching (input) ──
function switchTab(tab) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
  document.getElementById('tab-' + tab).classList.add('active');
  document.getElementById('pane-' + tab).classList.add('active');
}

// ── Result tab switching ──
function switchResult(tab) {
  document.querySelectorAll('.result-tab').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.result-pane').forEach(p => {
    p.classList.remove('active');
    p.classList.add('hidden');
  });
  document.getElementById('rtab-' + tab).classList.add('active');
  const pane = document.getElementById('rpane-' + tab);
  pane.classList.remove('hidden');
  pane.classList.add('active');
}

// ── Key toggle ──
function toggleKey() {
  const input = document.getElementById('api-key');
  const btn = document.getElementById('key-toggle');
  if (input.type === 'password') { input.type = 'text'; btn.textContent = '🙈'; }
  else { input.type = 'password'; btn.textContent = '👁'; }
}

// ── Toast ──
function showToast(msg, duration = 3000) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.remove('hidden');
  setTimeout(() => t.classList.add('hidden'), duration);
}

// ── Copy / Download ──
function copyResult(id) {
  const el = document.getElementById(id);
  if (!el) return;
  navigator.clipboard.writeText(el.textContent || el.innerText)
    .then(() => showToast('✅ Copied to clipboard!'))
    .catch(() => showToast('❌ Could not copy'));
}

function downloadTxt(id, filename) {
  const el = document.getElementById(id);
  if (!el) return;
  const text = el.textContent || el.innerText;
  const blob = new Blob([text], { type: 'text/plain' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  URL.revokeObjectURL(a.href);
  showToast('⬇️ Downloading ' + filename);
}

// ── Modal ──
function showComingSoon() {
  document.getElementById('modal-overlay').classList.remove('hidden');
}
function closeModal() {
  document.getElementById('modal-overlay').classList.add('hidden');
}
function joinWaitlist() {
  const email = document.getElementById('waitlist-email').value.trim();
  if (!email || !email.includes('@')) { showToast('⚠️ Enter a valid email'); return; }
  document.getElementById('modal-success').classList.remove('hidden');
  document.getElementById('waitlist-email').disabled = true;
  document.getElementById('join-waitlist-btn').disabled = true;
  // In production, POST to your backend / Stripe / ConvertKit
  console.log('Waitlist email:', email);
}

// ── Score ring animatoin ──
function animateScoreRing(score) {
  const ring = document.getElementById('score-ring');
  const numEl = document.getElementById('score-num');
  if (!ring || !numEl) return;
  const circumference = 2 * Math.PI * 40;
  ring.style.strokeDasharray = circumference;
  ring.style.strokeDashoffset = circumference;
  requestAnimationFrame(() => {
    ring.style.transition = 'stroke-dashoffset 1.2s cubic-bezier(0.4,0,0.2,1)';
    ring.style.strokeDashoffset = circumference - (score / 100) * circumference;
    let curr = 0;
    const interval = setInterval(() => {
      curr += 2;
      numEl.textContent = Math.min(curr, score) + '%';
      if (curr >= score) { numEl.textContent = score + '%'; clearInterval(interval); }
    }, 20);
  });
}

// ── Parse AI response ──
function parseAIResponse(raw) {
  // Extract sections from the JSON-like structure the AI sends back
  try {
    const parsed = JSON.parse(raw);
    return parsed;
  } catch {
    // Fallback: parse manually
    const sections = {};
    const blocks = raw.split(/===\s*([\w\s]+)\s*===/i);
    for (let i = 1; i < blocks.length; i += 2) {
      const key = blocks[i].trim().toLowerCase().replace(/\s+/g, '_');
      sections[key] = blocks[i + 1]?.trim() || '';
    }
    return sections;
  }
}

// ── Main Generate Function ──
const GEMINI_API_KEY = 'AIzaSyACIvF5oTXHccoZOVcg9_qTpoYLx748qWw';

async function generateKit() {
  const jd = document.getElementById('jd-input').value.trim();
  const resume = document.getElementById('resume-input').value.trim();
  const apiKey = GEMINI_API_KEY;

  if (!jd) { showToast('⚠️ Please paste a job description first'); switchTab('jd'); return; }
  if (!resume) { showToast('⚠️ Please paste your resume or skills'); switchTab('resume'); return; }

  // UI: Loading state
  const btn = document.getElementById('generate-btn');
  const btnText = btn.querySelector('.btn-text');
  const btnLoader = document.getElementById('btn-loader');
  btn.disabled = true;
  btnText.classList.add('hidden');
  btnLoader.classList.remove('hidden');

  document.getElementById('output-placeholder').classList.add('hidden');
  document.getElementById('results-container').classList.add('hidden');

  const prompt = `You are an expert career coach and ATS optimization specialist. A user is applying for a job and needs a complete job application kit.

IMPORTANT: Respond ONLY with valid JSON matching this exact structure (no markdown, no code fences, just raw JSON):
{
  "ats_score": <number 0-100>,
  "verdict": "<e.g. Strong Match / Good Match / Needs Work>",
  "keywords_added": ["keyword1", "keyword2", "keyword3", "keyword4", "keyword5"],
  "tailored_resume": "<full tailored resume text, well-formatted with sections>",
  "cover_letter": "<full cover letter, professional and personalized>",
  "interview_questions": "<5-7 likely interview questions with model answers, formatted clearly>"
}

JOB DESCRIPTION:
${jd}

CANDIDATE RESUME / SKILLS:
${resume}

Instructions:
- Tailor the resume to match the job description keywords and requirements
- Calculate ATS match score based on keyword overlap and relevance
- Write a compelling, personalized cover letter (not generic)
- Generate likely interview questions with strong model answers
- Keep the resume professional and ATS-friendly`;

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: {
            temperature: 0.7,
            maxOutputTokens: 3000,
            responseMimeType: 'application/json'
          }
        })
      }
    );

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      const msg = err?.error?.message || `API Error: ${response.status}`;
      showToast('❌ ' + msg);
      resetBtn();
      return;
    }

    const data = await response.json();
    const content = data.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!content) { showToast('❌ Empty response from Gemini'); resetBtn(); return; }

    let result;
    try {
      // Strip markdown code fences if present
      const clean = content.replace(/^```json\s*/i, '').replace(/```\s*$/, '').trim();
      result = JSON.parse(clean);
    }
    catch { showToast('❌ Could not parse Gemini response'); resetBtn(); return; }

    // ── Show results ──
    displayResults(result);

  } catch (err) {
    if (err.name === 'TypeError' && err.message.includes('fetch')) {
      showToast('❌ Network error. Check your internet connection.');
    } else {
      showToast('❌ Error: ' + err.message);
    }
    resetBtn();
  }
}

function resetBtn() {
  const btn = document.getElementById('generate-btn');
  btn.disabled = false;
  btn.querySelector('.btn-text').classList.remove('hidden');
  document.getElementById('btn-loader').classList.add('hidden');
}

function displayResults(result) {
  resetBtn();

  // Score
  const score = Math.min(100, Math.max(0, result.ats_score || 0));
  document.getElementById('score-num').textContent = '0%';
  document.getElementById('score-verdict').textContent = result.verdict || 'Analyzed';

  // Verdict color
  const verdictEl = document.getElementById('score-verdict');
  if (score >= 75) verdictEl.style.color = '#34D399';
  else if (score >= 50) verdictEl.style.color = '#FEBC2E';
  else verdictEl.style.color = '#F87171';

  // Keywords
  const kwContainer = document.getElementById('score-keywords');
  kwContainer.innerHTML = '';
  const keywords = result.keywords_added || [];
  keywords.slice(0, 6).forEach(kw => {
    const chip = document.createElement('div');
    chip.className = 'kw-chip';
    chip.textContent = kw;
    kwContainer.appendChild(chip);
  });

  // Content
  document.getElementById('resume-content').textContent = result.tailored_resume || 'No resume generated.';
  document.getElementById('cover-content').textContent = result.cover_letter || 'No cover letter generated.';
  document.getElementById('interview-content').textContent = result.interview_questions || 'No interview prep generated.';

  // Show results panel
  document.getElementById('results-container').classList.remove('hidden');
  switchResult('resume');

  // Animate score ring
  setTimeout(() => animateScoreRing(score), 100);

  // Scroll to output
  document.getElementById('output-panel').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  showToast('✅ Your job kit is ready!');
}

// ── Demo mode (no API key) ──
function runDemo() {
  const demoResult = {
    ats_score: 82,
    verdict: "Strong Match",
    keywords_added: ["React.js", "Node.js", "AWS", "Team Lead", "Agile", "CI/CD"],
    tailored_resume: `JOHN SMITH
john.smith@email.com | linkedin.com/in/johnsmith | GitHub: github.com/johnsmith

PROFESSIONAL SUMMARY
Results-driven Senior Software Engineer with 4+ years of experience building scalable React.js and Node.js applications. Proven track record leading engineering teams, architecting cloud-based solutions on AWS, and delivering products used by 100K+ users. Strong expertise in Agile/Scrum methodologies and CI/CD pipelines.

SKILLS
• Frontend: React.js, TypeScript, Next.js, Redux, HTML5, CSS3
• Backend: Node.js, Express, Python, REST APIs, GraphQL
• Cloud & DevOps: AWS (EC2, S3, Lambda, RDS), Docker, GitHub Actions, CI/CD
• Leadership: Team management, code reviews, mentoring, sprint planning

EXPERIENCE

Senior Software Engineer — Startup XYZ (2022 – Present)
• Led a team of 3 engineers to build a React.js dashboard used by 50K+ users
• Architected microservices backend in Node.js, reducing API latency by 40%
• Implemented CI/CD pipelines using GitHub Actions and AWS CodeDeploy
• Collaborated with product and design teams in Agile sprints (2-week cycles)

Software Engineer — Tech Corp (2020 – 2022)
• Developed React.js components for enterprise SaaS platform (200K+ users)
• Built RESTful APIs in Node.js/Express handling 1M+ daily requests
• Migrated legacy systems to AWS, reducing infrastructure costs by 30%

EDUCATION
B.S. Computer Science — State University (2020)`,

    cover_letter: `Dear Hiring Manager,

I am thrilled to apply for the Senior Software Engineer position at your company. With 4+ years of hands-on experience building production React.js and Node.js applications at scale, and a proven track record of leading engineering teams, I am confident I can make an immediate impact.

In my current role at Startup XYZ, I lead a team of 3 engineers building a React.js dashboard serving 50,000+ users. I have architected scalable microservices on AWS, implemented CI/CD pipelines, and worked closely with product teams in Agile sprints — all of which align directly with your job requirements.

What excites me most about this role is the opportunity to architect systems at even greater scale while mentoring a growing team. I thrive in fast-paced, collaborative environments and believe great software is built by empowered, well-supported teams.

I would love to discuss how my experience can contribute to your engineering goals.

Thank you for your consideration.

Best regards,
John Smith`,

    interview_questions: `INTERVIEW PREP KIT — Senior Software Engineer

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Q1: "Tell me about a challenging technical problem you solved recently."

MODEL ANSWER:
At Startup XYZ, we had a critical performance issue — our API response time spiked to 8 seconds during peak traffic. I led an investigation, identified N+1 database queries as the root cause, implemented Redis caching, and refactored query logic. Result: response time dropped from 8s to 200ms. This required coordinating with 2 other engineers and deploying with zero downtime.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Q2: "How do you lead a team of engineers effectively?"

MODEL ANSWER:
I believe in servant leadership — my job is to unblock my team, not micromanage. I run structured 1:1s weekly, maintain clear sprint goals in Jira, and do thorough but constructive code reviews. I also invest in pair programming for complex tickets. At my current company, this approach reduced our sprint velocity variance by 35%.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Q3: "How do you ensure your applications are scalable on AWS?"

MODEL ANSWER:
I architect for horizontal scalability from the start: stateless services behind load balancers, database connection pooling, S3 for static assets, Lambda for event-driven workloads, and CloudWatch for monitoring. I also practice infrastructure-as-code with Terraform for reproducibility.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Q4: "Describe your experience with Agile/Scrum."

MODEL ANSWER:
I've worked in Agile for 4 years. I'm comfortable estimating story points, running retrospectives, and adapting mid-sprint when priorities shift. I believe the key is keeping standups short (15 min), backlogs well-groomed, and retrospective actions actually happening — not just being discussed.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Q5: "Where do you see yourself in 3 years?"

MODEL ANSWER:
I want to grow into a Staff or Principal Engineer role where I can influence architectural decisions at a company level, mentor multiple teams, and contribute to engineering culture. I'm particularly interested in the intersection of developer experience and system reliability.`
  };
  displayResults(demoResult);
}

// Add demo button if no API key is entered
document.getElementById('generate-btn').addEventListener('click', () => { }, false);

// Re-bind the click handler cleanly
document.getElementById('generate-btn').onclick = null;
document.getElementById('generate-btn').addEventListener('click', () => generateKit());

// ── Intersection Observer for step card animations ──
const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry, i) => {
    if (entry.isIntersecting) {
      setTimeout(() => {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
      }, i * 100);
    }
  });
}, { threshold: 0.15 });

document.querySelectorAll('.step-card, .price-card').forEach(el => {
  el.style.opacity = '0';
  el.style.transform = 'translateY(30px)';
  el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
  observer.observe(el);
});
